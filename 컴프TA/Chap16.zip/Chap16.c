#include <Windows.h>
#include <conio.h>
#include <stdio.h>
#include <stdarg.h>
#include <ctype.h>

#define DEBUG (0)
#define LEVEL (3)
#define POWER_TYPE (3)
double power(int x, int y) {
	double result = 1.0;
	for (int i = 0; i < y; ++i)
	{

#ifdef DEBUG
		printf("%d: result=%f\n", __LINE__, result);
#if DEBUG==2
		printf("%d: result=%f\n", __LINE__, result);
#if DEBUG == 2 && LEVEL == 3
		printf("%d: result=%f\n", __LINE__, result);
#if	0	printf("%d: result=%f\n", __LINE__, result);
#endif
#endif
#endif
#endif
		result *= x;
	}
#if POWER_TYPE == 0
	return (int)result;
#elif POWER_TYPE == 1
	return (double)result;
#endif
	return result;
}
void Q1() {
	printf("%d^%d = %lf\n", 2, 3, power(2, 3));
}

#define GET_MIN(x,y,z) ((x < y) ? (x < z) ? x : z : (y < z) ? y : z)
void Q2() {
	int a, b, c;
	printf("3���� ������ �Է��Ͻÿ�: "); scanf_s(" %d %d %d", &a, &b, &c);
	int min = GET_MIN(a, b, c);
	printf("�ּڰ��� %d�Դϴ�.\n", min);
}

#define ARRAY_INT(arr, size, value) do {\
for (int i = 0; i < size; ++i) { *(arr+i) = value; } \
} while(0)
void Q3() {
	int arr[9] = { 0, };
	int len = sizeof(arr) / sizeof(int);
	ARRAY_INT(arr, len, 3);
	printf("[");
	for (int i = 0; i < len; ++i) printf(" %d", arr[i]);
	printf(" ]");
}

#define PI (3.141592)
#define VOLUME(r, h) (PI * r * r * h)
void Q4() {
	int r, h; 
	printf("������� �������� �Է��Ͻÿ�: "); scanf_s(" %d", &r);
	printf("������� ���̸� �Է��Ͻÿ�: "); scanf_s(" %d", &h);
	double volume = VOLUME(r, h);
	printf("������� ����: %lf", volume);
}

#define IS_SPACE(c) (c == ' ' || c == '\t' || c == '\n') ? 1 : 0
void Q5() {
	char str[128] = { 0 };
	int len = sizeof(str) / sizeof(char);
	printf("���ڿ��� �Է��Ͻÿ�: "); scanf_s("%[^\n]s", str, len);
	int sum = 0;
	for (int i = 0; i < len; ++i) sum += IS_SPACE(str[i]);
	printf("���鹮���� ����: %d", sum);
}

#define SET_BIT(n, pos) ((n) |= (1 << (pos)))
#define CLR_BIT(n, pos) ((n) &= (~(1U) << (pos)))
#define GET_BIT(n, pos) (((n) & (1 << (pos))) >> pos)
void Q6() {
	int n = 1024, pos = 10;
	printf("n=%#x\n", n);
	printf("GET_BIT(%#x, %d): %d\n", n, pos, GET_BIT(n, pos));
	printf("n=%#x\n", n);
	printf("CLR_BIT(%#x, %d)\n", n, pos); CLR_BIT(n, pos);
	printf("n=%#x\n", n);
	printf("SET_BIT(%#x, %d)\n", n, pos); SET_BIT(n, pos);
	printf("n=%#x\n", n);
}

void disply_bit(int value) {
	for (int i = sizeof(int) * 8 - 1; i >= 0; --i) printf("%d", GET_BIT(value, i));
	puts("");
}
void Q7() {
	int num;
	printf("�������� �Է��Ͻÿ�: "); scanf_s(" %d", &num);
	disply_bit(num); 
}

void Q8() {
	int num, moveType, moveLength;
	printf("�������� �Է��Ͻÿ�: "); scanf_s(" %d", &num);
	printf("���� �̵��� 0, ������ �̵��� 1�� �Է��Ͻÿ�: "); scanf_s(" %d", &moveType);
	printf("�̵���ų �Ÿ�: "); scanf_s(" %d", &moveLength);
	printf("�̵� ��: "); disply_bit(num);
	if (moveType) num >>= moveLength;
	else num <<= moveLength;
	printf("�̵� ��: "); disply_bit(num);
}


void Q9() {
	char str[128] = { 0 };
	int len = sizeof(str) / sizeof(char);
	printf("���ڿ��� �Է��Ͻÿ�: "); scanf_s(" %[^\n]s", str, len);

	for (int i = 0; i < len && str[i] != '\0'; ++i)
		if (isalpha(str[i])) str[i] ^= 32;

	printf("��� ���ڿ�: %s", str);
}

void Q10() {
	char str[] = "I am a boy";
	int len = sizeof(str) / sizeof(char);

	printf("Encoded [ %s ] ", str);
	for (int i = 0; i < len && str[i] != '\0'; ++i) str[i] ^= 2;
	printf("to [ %s ]\n", str);

	printf("Decoded [ %s ] ", str);
	for (int i = 0; i < len && str[i] != '\0'; ++i) str[i] ^= 2;
	printf("to [ %s ]\n", str);
}

int main() {
	void* Questions[] = { NULL, Q1, Q2, Q3, Q4, Q5, Q6, Q7, Q8, Q9, Q10 };
	int nQ, sizeQ = sizeof(Questions) / sizeof(void*) - 1;

	while (1) {
		system("cls");
		printf("#Question(%d~%d): ", 1, sizeQ); scanf_s(" %d", &nQ);
		while (getchar() != '\n');
		if (nQ < 1 || nQ > sizeQ) break;

		void (*fp)();
		fp = Questions[nQ];
		fp();

		printf("\nPress any key to continue..."); while (!_getch());
	}
	return 0;
}

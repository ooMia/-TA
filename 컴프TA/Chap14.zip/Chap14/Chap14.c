﻿#include <stdio.h>
#include <string.h>
#include "my2DArrayMalloc.h"
#include "gameOfLife.h"

void set_proverb(char** q, int n)
{
	static char* stringList[] = {
	"A bad shearer never had a good sickle.",
	"A bad workman (always) blames his tools.",
	"A bad thing never dies.",
	"A barking dog never bites." ,
	"A big fish in a small pond." ,
	"No pain No gain." ,
	"A good medicine tastes bitter." ,
	"It never rains but it pours.",
	"The more, the better.",
	"Walls have ears."
	}; *q = stringList[n];
}
void Q1()
{
	int n;
	printf("몇번째 속담을 선택하시겠습니까? ");
	scanf_s(" %d", &n);
	n = (--n < 0) ? -n : n % 10;

	char* s;
	set_proverb(&s, n);
	printf("selected proverb = %d %s\n", n + 1, s);
}
int get_sum(int* intList, int size) {
	int sum = 0;
	for (int i = 0; i < size; i++)
		sum += *(intList + i);
	return sum;
}
void Q2()
{
	int intList[][6] = {
		{10, 10, 10, 10, 10, 10},
		{10, 10, 10, 10, 10, 10},
		{10, 10, 10, 10, 10, 10}
	};
	int cols = 6, rows = sizeof(intList) / sizeof(int) / cols;

	int sum = 0;
	for (int row = 0; row < rows; row++)
		sum += get_sum(intList[row], cols);
	printf("정수의 합 = %d\n", sum);
}
double get_average(int* intList, int n) {
	double sum = 0;
	for (int i = 0; i < n; i++)
		sum += *(intList + i);
	return sum / n;
}
void Q3() {
	int intList[][6] =	{
		{62, 63, 64, 66, 67, 68},
		{35, 40, 45, 55, 60, 65},
		{50, 52, 54, 58, 60, 62}
	};
	int cols = 6, rows = sizeof(intList) / sizeof(int) / cols;

	for (int row = 0; row < rows; row++)
		printf("%d행의 평균값 = %.1lf\n",
			row, get_average(intList[row], cols));
}
void pr_str_array(char** str, int len) {
	for (int i = 0; i < len; i++)
		printf("%2d %s\n", i + 1, *(str + i));
}
void Q4() {
	char* stringList[] = {
	"A bad shearer never had a good sickle.",
	"A bad workman (always) blames his tools.",
	"A bad thing never dies.",
	"A barking dog never bites." ,
	"A big fish in a small pond." ,
	"No pain No gain." ,
	"A good medicine tastes bitter." ,
	"It never rains but it pours.",
	"The more, the better.",
	"Walls have ears."
	};
	size_t len = sizeof(stringList) / sizeof(size_t);
	pr_str_array(stringList, len);
}
void set_max_ptr(int m[], int size, int** pmax) {
	*pmax = m;
	for (int i = 1; i < size; i++) if (**pmax < *(m + i)) *pmax = m + i;
}
void Q5() {
	int m[6] = { 5,6,1,3,7,9 };
	int* pmax; // 배열 m의 원소 중에서 가장 큰 값을 pmax가 가리킨다.
	set_max_ptr(m, 6, &pmax);
	printf("가장 큰 값은 %d\n", *pmax);
}
void sort_strings(const char* list[], int size)
{
	int i, j, least;
	const char* temp;

	for (i = 0; i < size - 1; i++) 
	{
		least = i; // i번째 값을 최솟값으로 가정
		for (j = i + 1; j < size; j++) // 최솟값 탐색
			if (strcmp(list[j], list[least]) < 0)
				least = j;
		// i번째 요소와 least 위치의 요소를 교환
		temp = list[i];
		list[i] = list[least];
		list[least] = temp;
	}
}
void Q6() {
	char* stringList[] = { "mycopy", "src", "dst" };
	size_t len = sizeof(stringList) / sizeof(size_t);
	sort_strings(stringList, (int)len);
	pr_str_array(stringList, len);
}
typedef unsigned char pixel;
void binarization(pixel** image, int rows, int cols, pixel threshold) {
	for (int r = 0; r < rows; r++)
		for (int c = 0; c < cols; c++)
			*(*(image + r) + c) = *(*(image + r) + c) < threshold ? 0 : 255;
}
void Q7() {
	pixel rawImage[10][10] = {
	{0,0,0,0,222,0,0,0,0,0},
	{0,0,0,222,130,0,0,0,0,0},
	{0,0,222,0,151,0,0,0,0,0},
	{0,0,0,0,209,0,0,0,0,0},
	{0,0,0,0,213,0,0,0,0,0},
	{0,0,0,0,175,0,0,0,0,0},
	{0,0,0,0,199,0,0,0,0,0},
	{0,0,0,0,138,0,0,0,0,0},
	{0,0,0,0,164,0,0,0,0,0},
	{0,0,178,146,135,213,200,0,0,0},
	};

	pixel** image;
	int rows = 10, cols = 10;
	copyArray(true, rawImage, image, pixel, rows, cols); // Memory Allocation & Copy rawImage Data

	// Main Logic
	binarization(image, rows, cols, 128);
	for (int r = 0; r < rows; r++) {
		for (int c = 0; c < cols; c++) printf("%3d ", image[r][c]);
		puts("");
	}

	free2DArray(image, rows); // Free Allocated Memory
}
void array_copy(int** src, int** dst, int rows, int cols) {
	for (int r = 0; r < rows; r++)
		for (int c = 0; c < cols; c++)
			*(*(dst + r) + c) = *(*(src + r) + c);
}
void Q8() {
	int numbers[3][3] = {
		{100,30,67},
		{89,50,12},
		{19,60,90}
	};
	int rows = 3, cols = 3;
	int** intList; copyArray(true, numbers, intList, int, rows, cols);
	int** intListCopied; copyArray(false, (int**)NULL, intListCopied, int, rows, cols);

	array_copy(intList, intListCopied, rows, cols);
	puts("<원본 2차원 배열>");
	for (int r = 0; r < rows; r++) {
		for (int c = 0; c < cols; c++) printf("%3d ", intList[r][c]);
		puts("");
	}
	puts("<복사본 2차원 배열>");
	for (int r = 0; r < rows; r++){
		for (int c = 0; c < cols; c++) printf("%3d ", intListCopied[r][c]);
		puts("");
	}

	free2DArray(intList, rows);
	free2DArray(intListCopied, rows);
}

void Q9() {
	int initMap[20][20] = {
		{0,0,0,0,0,0,0,0,0,1,1,1,1,1},
		{0},
		{0},
		{0},
		{0},
		{0,1,1,1},
		{0},
		{0},
		{0},
		{0},
		{0},
		{0,1,1,1},
		{0,1,1,1},
		{0,1,1,1}
	};
	int rows = 20, cols = 20;

	int** initMap2;
	copyArray(true, initMap, initMap2, int, rows, cols);
	runGameOfLife(initMap2, rows, cols, 100);
	free2DArray(initMap2, rows);
}
int main() {
	puts("Q1"), Q1(), puts("");
	puts("Q2"), Q2(), puts("");
	puts("Q3"), Q3(), puts("");
	puts("Q4"), Q4(), puts("");
	puts("Q5"), Q5(), puts("");
	puts("Q6"), Q6(), puts("");
	puts("Q7"), Q7(), puts("");
	puts("Q8"), Q8(), puts("");
	puts("Q9"), Q9(), puts("");
	return 0;
}

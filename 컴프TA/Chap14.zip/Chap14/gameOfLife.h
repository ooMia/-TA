#ifndef GAME_OF_LIFE_H
#define GAME_OF_LIFE_H

#include <stdio.h>
#include "my2DArrayMalloc.h"
#include <Windows.h>

struct Point2D { int x, y; };

void runGameOfLife(int** map, int rows, int cols);

#endif // !GAME_OF_LIFE_H

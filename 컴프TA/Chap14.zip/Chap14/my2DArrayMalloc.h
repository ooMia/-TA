#ifndef MY_2D_ARRAY_MALLOC_H
#define MY_2D_ARRAY_MALLOC_H

#include <malloc.h>
#include <stdbool.h>

#define copyArray(doCopy, from, to, type, rows, cols)\
do{\
	if ((to = (type**)malloc(sizeof(type*) * rows)) == NULL) return;\
	for (int r = 0; r < rows; r++) {\
		if ((to[r] = (type*)malloc(sizeof(type) * cols)) == NULL) return;\
		if (doCopy) for (int c = 0; c < cols; c++) *(*(to + r) + c) = *(*(from + r) + c);\
	}\
}while(0)

#define free2DArray(arr, rows)\
do{\
	for (int r = 0; r < rows; r++) free(arr[r]);\
	free(arr);\
}while(0)

#endif // !MY_2D_ARRAY_MALLOC_H

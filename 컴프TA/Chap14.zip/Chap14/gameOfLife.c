#include "gameOfLife.h"

static int rows, cols;

static int countNeighbors(int** location, int centerY, int centerX) {
	int nNeighbors = 0;
	for (int y = centerY - 1; y <= centerY + 1; y++)
		for (int x = centerX - 1; x <= centerX + 1; x++) {
			if ((x == centerX && y == centerY) ||
				x < 0 || rows <= x || y < 0 || cols <= y) continue;
			nNeighbors += *(*(location + y) + x) > 0;
		}
	return nNeighbors;
}

static void getNextGeneration(int** from, int** to) {
	for (int r = 0; r < rows; r++) {
		for (int c = 0; c < cols; c++)
			switch (countNeighbors(from, r, c))
			{
			case 3: *(*(to + r) + c) = 1; break; // ź��
			case 2: *(*(to + r) + c) = *(*(from + r) + c); break; // ����
			default: *(*(to + r) + c) = 0; break; // ����
			}
	}
}

void runGameOfLife(int** map1, int initRows, int initCols, int iterSpeed)
{
	// INITIALIZE TWO MAPS
	if (map1 == NULL || initRows <= 0 || initCols <= 0) return;
	int** map2;
	copyArray(true, map1, map2, int, (rows = initRows), (cols = initCols));

	// GET NUMBER OF ITERATION
	int nIter = 0, maxIter;
	printf("Generation %d\n", nIter);
	for (int r = 0; r < rows; r++) {
		for (int c = 0; c < cols; c++) printf("%c ", map1[r][c] ? 'X' : '-');
		puts("");
	}
	do {
		printf("n of iteration (0:infinite): "); scanf_s(" %d", &maxIter);
	} while (maxIter < 0);

	// PLAY GAME
	int** from, ** to;
	do {
		from = (nIter % 2) ? map1 : map2;
		to   = (nIter % 2) ? map2 : map1;

		getNextGeneration(from, to);
		system("cls");
		printf("Generation %d\n", ++nIter);
		for (int r = 0; r < rows; r++) {
			for (int c = 0; c < cols; c++) printf("%c ", to[r][c] ? 'X' : '-');
			puts("");
		}
		Sleep(iterSpeed);

	} while (nIter != maxIter);

	// FREE ALLOCATED MEMORY
	free2DArray(map2, rows);
}

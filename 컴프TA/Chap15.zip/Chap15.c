﻿#define _CRT_SECURE_NO_WARNINGS

#include <Windows.h>
#include <conio.h>
#include <stdlib.h>
#include <time.h>
#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include <stdarg.h>
#include <ctype.h>

const char* file[] = {
	"src/sample.txt", "src/sample1.txt", "src/sample2.txt",
	"src/img.jpg", "src/img1.jpg", "src/img2.jpg",
	"src/studentData.txt", "src/studentStat.txt"
};

#define BUF_LEN (256)
bool isSameFile(const char* fileNameA, const char* fileNameB)
{
	FILE* fileA = NULL; char tmpA[BUF_LEN] = { 0, }; size_t numA;
	FILE* fileB = NULL; char tmpB[BUF_LEN] = { 0, }; size_t numB;
	bool res = false;
	if ((fileA = fopen(fileNameA, "rb")) != NULL &&
		(fileB = fopen(fileNameB, "rb")) != NULL)
	{
		while (true) {
			memset(tmpA, 0, BUF_LEN);
			memset(tmpB, 0, BUF_LEN);
			numA = fread(tmpA, sizeof(char), BUF_LEN - 1, fileA);
			numB = fread(tmpB, sizeof(char), BUF_LEN - 1, fileB);
			if (numA == 0 && numB == 0) { res = true; break; }
			if (numA != numB || strcmp(tmpA, tmpB) != 0) {
				puts("====================LOG====================");
				printf("- <%s>\n%s\n\n- <%s>\n%s\n", fileNameA, tmpA, fileNameB, tmpB);
				puts("===========================================");
				break;
			}
		}
	}
	if (fileA != NULL) fclose(fileA);
	if (fileB != NULL) fclose(fileB);
	return res;
}
void Q1() {
	printf("\n> %s & %s : %s\n\n", file[0], file[1], isSameFile(file[0], file[1]) ? "same" : "not same");
	printf("\n> %s & %s : %s\n\n", file[0], file[2], isSameFile(file[0], file[2]) ? "same" : "not same");
	printf("\n> %s & %s : %s\n\n", file[3], file[4], isSameFile(file[3], file[4]) ? "same" : "not same");
	printf("\n> %s & %s : %s\n\n", file[3], file[5], isSameFile(file[3], file[5]) ? "same" : "not same");
}


// 12-6
char* str_upper(char* s) {
	int i = 0; char ch;
	while ((ch = s[i++]) != '\0')
		if ('a' <= ch && ch <= 'z') s[i - 1] = ch - 'a' + 'A';
	return s;
}
bool convertTextFileToUpperCase(const char* srcTextFileName, const char* destTextFileName)
{
	FILE* srcFile = NULL; size_t numA; char tmpA[BUF_LEN] = { 0, };
	FILE* destFile = NULL; size_t numB;
	bool res = false;
	if ((srcFile = fopen(srcTextFileName, "r")) != NULL &&
		(destFile = fopen(destTextFileName, "w")) != NULL)
	{
		while (true) {
			memset(tmpA, 0, BUF_LEN);
			numA = fread(tmpA, sizeof(char), BUF_LEN - 1, srcFile);
			if (numA == 0) { res = true; break; }
			char* tmpB = str_upper(tmpA);
			numB = fwrite(tmpB, sizeof(char), numA, destFile);
			printf("%s", tmpB);
		}
	}
	if (srcFile != NULL) fclose(srcFile);
	if (destFile != NULL) fclose(destFile);
	return res;
}
void Q2() {
	const char* readTextFileFrom = file[0];
	const char* writeTextFileTo = "src/upperCase.txt";
	printf("대문자 변환 파일: %s\n", readTextFileFrom);
	printf("　변환 결과 저장: %s\n\n", writeTextFileTo);
	printf("\n%s\n", convertTextFileToUpperCase(readTextFileFrom, writeTextFileTo) ? "Okay" : "ERROR");
}


bool copyFile(const char* srcFileName, const char* destFileName) {
	FILE* srcFile = NULL; size_t numA; char tmpA[BUF_LEN] = { 0, };
	FILE* destFile = NULL; size_t numB;
	bool res = false;
	if ((srcFile = fopen(srcFileName, "rb")) != NULL &&
		(destFile = fopen(destFileName, "wb")) != NULL)
	{
		while (true) {
			numA = fread(tmpA, sizeof(char), BUF_LEN, srcFile);
			if (numA == 0) { res = true; break; }
			numB = fwrite(tmpA, sizeof(char), numA, destFile);
		}
	}
	if (srcFile != NULL) fclose(srcFile);
	if (destFile != NULL) fclose(destFile);
	return res;
}
void Q3() {
	const char* readTextFileFrom = file[3];
	const char* writeTextFileTo = file[4];
	printf("원본 파일: %s\n", readTextFileFrom);
	printf("복사 파일: %s\n\n", writeTextFileTo);
	printf("\n%s\n", copyFile(readTextFileFrom, writeTextFileTo) ? "Okay" : "ERROR");
}


bool isSameTextFile(const char* textFileNameA, const char* textFileNameB)
{
	FILE* fileA = NULL; char tmpA[BUF_LEN] = { 0, }, * resA;
	FILE* fileB = NULL; char tmpB[BUF_LEN] = { 0, }, * resB;
	bool res = false;
	if ((fileA = fopen(textFileNameA, "r")) != NULL &&
		(fileB = fopen(textFileNameB, "r")) != NULL)
	{
		while (true) {
			memset(tmpA, 0, BUF_LEN);
			memset(tmpB, 0, BUF_LEN);

			resA = fgets(tmpA, BUF_LEN, fileA);
			resB = fgets(tmpB, BUF_LEN, fileB);

			if (resA == NULL || resB == NULL) {
				res = (resA == resB) ? true : false;
				break;
			}
			if (strcmp(tmpA, tmpB) != 0) {
				puts("====================LOG====================");
				printf("- <%s>\n%s\n\n- <%s>\n%s\n", textFileNameA, tmpA, textFileNameB, tmpB);
				puts("===========================================");
				break;
			}
		}
	}
	if (fileA != NULL) fclose(fileA);
	if (fileB != NULL) fclose(fileB);
	return res;
}
void Q4() {
	printf("\n> %s & %s : %s\n\n", file[0], file[1], isSameTextFile(file[0], file[1]) ? "same" : "not same");
	printf("\n> %s & %s : %s\n\n", file[0], file[2], isSameTextFile(file[0], file[2]) ? "same" : "not same");
}

typedef double element;
element getAverage(int nArgs, ...)
{
	element sum = 0;

	va_list args;
	va_start(args, nArgs);
	for (int i = 0; i < nArgs; i++)
		sum += va_arg(args, element);
	va_end(args);

	return sum / nArgs;
}
bool convertStudentDataToStatistic(const char* studentDataFileName, const char* studentStatFileName)
{
	FILE* dataFile = NULL;
	FILE* statFile = NULL;
	bool res = false;
	if ((dataFile = fopen(studentDataFileName, "r")) != NULL &&
		(statFile = fopen(studentStatFileName, "w")) != NULL)
	{
		char tmp[BUF_LEN] = { 0, };
		element sub[3];

		if (fscanf(dataFile, " %s %*[^\n]", tmp));
		fprintf(statFile, "%s\t%s\n", tmp, "평균");

		while (true) {
			memset(tmp, 0, BUF_LEN);
			if (fscanf(dataFile, " %s %lf %lf %lf", tmp, sub, sub + 1, sub + 2) != 4) break;
			fprintf(statFile, "%s\t%.2lf\n", tmp, getAverage(3, sub[0], sub[1], sub[2]));
		}
	}
	if (dataFile != NULL) fclose(dataFile);
	if (statFile != NULL) fclose(statFile);
	return res;
}
bool printFile(const char* fileName) {
	FILE* file = NULL; char tmp[BUF_LEN] = { 0, };
	bool res = false;
	if ((file = fopen(fileName, "r")) != NULL)
	{
		while (true) {
			memset(tmp, 0, BUF_LEN);
			if (fgets(tmp, BUF_LEN, file) == NULL) { res = true; break; }
			else printf("%s", tmp);
		}
	}
	if (file != NULL) fclose(file);
	return res;
}
void Q5() {
	// TEXT FILE ENCODING: ANSI
	if (printFile(file[6]));
	printf("\nConverting...");
	convertStudentDataToStatistic(file[6], file[7]);
	puts("finished!\n");
	if (printFile(file[7]));
}


int str_countPrintable(char* s) {
	int i = 0, sum = 0;
	char ch;
	while ((ch = s[i++]) != '\0') sum += (isprint(ch) > 0);
	return sum;
}
int countPrintable(const char* fileName) {
	FILE* file = NULL; char tmp[BUF_LEN] = { 0, };
	int sum = 0;
	if ((file = fopen(fileName, "r")) != NULL)
	{
		while (true) {
			memset(tmp, 0, BUF_LEN);
			if (fgets(tmp, BUF_LEN, file) == NULL) break;
			else sum += str_countPrintable(tmp);
		}
	}
	if (file != NULL) fclose(file);
	return sum;
}
void Q6() {
	if (printFile(file[2]));
	printf("\n\n> countPrintable(%s) : %d\n\n", file[2], countPrintable(file[2]));
}


void writeTextFileFromStdin(const char* destTextFileName) {
	FILE* destTextFile = NULL; char tmp[BUF_LEN] = { 0, };
	if ((destTextFile = fopen(destTextFileName, "w")) != NULL)
	{
		while (true) {
			if (fgets(tmp, BUF_LEN, stdin) == NULL) break;
			fputs(tmp, destTextFile);
		}
	}
	if (destTextFile != NULL) fclose(destTextFile);
}
void Q7() {
	printf("출력 파일 : %s\n", "src/foo.c");
	writeTextFileFromStdin("src/foo.c");
}

typedef double element;
bool makeFile(bool isTextFile, const char* fileName, int nArgs)
{
	FILE* file = NULL;
	char tmp[BUF_LEN] = { 0, };
	bool res = false;
	if ((file = fopen(fileName, "w")) != NULL)
	{
		for (int i = 0; i < nArgs; i++) {
			if (isTextFile) fprintf(file, "%lf", (double)rand());
			else {
				sprintf(tmp, "%lf", (double)rand());
				fwrite(tmp, sizeof(element), 1, file);
			}
		}
	}
	if (file != NULL) fclose(file);
	return res;
}
void Q8() {
	srand((unsigned)time(NULL));
	int iter = 100;
	makeFile(true, "src/randTextFile.txt", iter);
	makeFile(false, "src/randBinaryFile.txt", iter);
}

bool mergeTextFile(const char* srcFileNameA, const char* srcFileNameB, const char* destFileName) {
	copyFile(srcFileNameA, destFileName);

	FILE* srcFile = NULL; size_t numA; char tmpA[BUF_LEN] = { 0, };
	FILE* destFile = NULL; size_t numB;
	bool res = false;
	if ((srcFile = fopen(srcFileNameB, "rb")) != NULL &&
		(destFile = fopen(destFileName, "ab")) != NULL)
	{
		while (true) {
			numA = fread(tmpA, sizeof(char), BUF_LEN, srcFile);
			if (numA == 0) { res = true; break; }
			numB = fwrite(tmpA, sizeof(char), numA, destFile);
		}
	}
	if (srcFile != NULL) fclose(srcFile);
	if (destFile != NULL) fclose(destFile);
	return res;
}
void tempMain(int argc, char* argv[]) {
	printf("%s 파일 + %s 파일을 %s 파일로 복사합니다.\n", argv[1], argv[2], argv[3]);
	mergeTextFile(argv[1], argv[2], argv[3]);
}
void Q9() {
	char* argv[] = { "(dir)", "src/mergeHello.c", "src/mergeMain.c", "src/mergeDst.c" };
	tempMain(sizeof(argv) / sizeof(char*), argv);
}

bool printFileWithLineNumbers(const char* fileName) {
	FILE* file = NULL; char tmp[BUF_LEN] = { 0, };
	bool res = false; int line = 0;
	if ((file = fopen(fileName, "r")) != NULL)
	{
		while (true) {
			memset(tmp, 0, BUF_LEN);
			if (fgets(tmp, BUF_LEN, file) == NULL) { res = true; break; }
			else printf("%6d: %s", ++line, tmp);
		}
	}
	if (file != NULL) fclose(file);
	return res;
}
void Q10() { printFileWithLineNumbers(file[0]); }

// 생략
void Q11() {}

bool printLineIncludeTargetWord(const char* fileName, const char* target) {
	FILE* file = NULL; char tmp[BUF_LEN] = { 0, };
	bool res = false; int line = 0;
	if ((file = fopen(fileName, "r")) != NULL)
	{
		while (true) {
			++line;
			memset(tmp, 0, BUF_LEN);
			if (fgets(tmp, BUF_LEN, file) == NULL) { res = true; break; }
			else if (strstr(tmp, target) != NULL) printf("%6d: %s", line, tmp);
		}
	}
	if (file != NULL) fclose(file);
	return res;
}
void Q12() {
	printLineIncludeTargetWord(file[0], "of");
}

// 12-14
char* str_replace(char* res, const char* str, const char* from, const char* to) {
	int iRes = 0, iStr = 0, iFrom = 0, iTo = 0,
		lenStr = (int)strlen(str), lenFrom = (int)strlen(from), lenTo = (int)strlen(to);

	while (str[iStr] != '\0') {
		res[iRes] = str[iStr];
		if (strncmp(str + iStr, from, lenFrom) == 0) {
			for (int i = 0; i < lenTo; i++)
				if (iRes + i < 80) res[iRes + i] = to[i];
			iStr += lenFrom - 1, iRes += lenTo - 1;
		}
		iStr++, iRes++;
	}
	res[iRes] = '\0';
	return res;
}
bool saveAsTextFileWithWordReplaced(
	const char* srcTextFileName, const char* destTextFileName,
	const char* textFrom, const char* textTo)
{
	FILE* srcFile = NULL; char  srcBuf[BUF_LEN] = { 0, };
	FILE* destFile = NULL; char destBuf[BUF_LEN] = { 0, };
	bool res = false;

	if ((srcFile = fopen(srcTextFileName, "r")) != NULL &&
		(destFile = fopen(destTextFileName, "w")) != NULL)
	{
		while (true) {
			memset(srcBuf, 0, BUF_LEN);
			memset(destBuf, 0, BUF_LEN);
			if (fgets(srcBuf, BUF_LEN, srcFile) == NULL) { res = true; break; }
			str_replace(destBuf, srcBuf, textFrom, textTo);
			fputs(destBuf, destFile);
		}
	}
	if (srcFile != NULL) fclose(srcFile);
	if (destFile != NULL) fclose(destFile);
	return res;
}
void Q13() { saveAsTextFileWithWordReplaced(file[0], "src/replacedSample.txt", "to", "TO"); }


int main() {
	void* Questions[] = { NULL, Q1, Q2, Q3, Q4, Q5, Q6, Q7, Q8, Q9, Q10, Q11, Q12, Q13 };
	int nQ, sizeQ = sizeof(Questions) / sizeof(void*) - 1;

	while (1) {
		system("cls");
		printf("#Question(%d~%d): ", 1, sizeQ); scanf_s(" %d", &nQ);
		while (getchar() != '\n');
		if (nQ < 1 || nQ > sizeQ) break;

		void (*fp)();
		fp = Questions[nQ];
		fp();

		printf("\nPress any key to continue..."); while (!_getch());
	}
	return 0;
}

#include <stdio.h>
void hello();
void hello(){
printf("Hello, World!");
}
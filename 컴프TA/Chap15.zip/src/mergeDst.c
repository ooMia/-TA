#include <stdio.h>
void hello();
void hello(){
printf("Hello, World!");
}#include <stdio.h>
int main(){
hello();
return 0;
}
#include <stdio.h>
int main(){
hello();
return 0;
}